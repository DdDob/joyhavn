# Joyhavn contracts (draft)

A working reference implementation of a safe protocol wind-down.

- `IJoyhavn.sol`: the standard interface wallets can read.
- `Joyhavn.sol`: phase machine (Active, WindDown, ExitOnly, Archived).
- `JoyhavnVault.sol`: example protocol using it (single-token vault).
- `HostingEscrow.sol`: prepaid ETH escrow that pays hosting/RPC per period.
- `test/Joyhavn.t.sol`: Foundry tests.

## Run
```
curl -L https://foundry.paradigm.xyz | bash && foundryup
forge init --no-commit --force .   # if starting from an empty folder
forge install foundry-rs/forge-std --no-commit
forge test -vv
```

## Rules the code enforces
- Phases only move forward; wind-down needs at least 7 days public notice.
- Deposits only in Active; withdrawals in every phase, no admin override.
- Exit frontend hash is frozen once wind-down begins.
- Archive only when nothing is left to withdraw.

## Before mainnet
Not audited and not compiled in the environment it was written in. Get a
professional audit, test on a testnet, and have a lawyer review the setup.
