// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Joyhavn} from "./Joyhavn.sol";

/// @notice Example protocol: an ETH vault with Joyhavn built in.
contract JoyhavnEthVault is Joyhavn {
    mapping(address => uint256) public balanceOf;
    uint256 public totalDeposits;

    event Deposited(address indexed user, uint256 amount);
    event Withdrawn(address indexed user, address indexed to, uint256 amount);

    error ZeroAmount();
    error InsufficientBalance();
    error TransferFailed();

    constructor(address governance_, bytes32 exitFrontend_) Joyhavn(governance_, exitFrontend_) {}

    function deposit() external payable whenActive {
        if (msg.value == 0) revert ZeroAmount();
        balanceOf[msg.sender] += msg.value;
        totalDeposits += msg.value;
        emit Deposited(msg.sender, msg.value);
    }

    function withdraw(uint256 amount, address to) external {
        if (amount == 0) revert ZeroAmount();
        _withdraw(msg.sender, amount, to);
    }

    function withdrawAll(address to) external override returns (uint256 amount) {
        amount = balanceOf[msg.sender];
        if (amount == 0) revert ZeroAmount();
        _withdraw(msg.sender, amount, to);
    }

    function _withdraw(address user, uint256 amount, address to) internal {
        if (to == address(0)) revert ZeroAddress();
        if (amount > balanceOf[user]) revert InsufficientBalance();
        balanceOf[user] -= amount; // effects before interaction
        totalDeposits -= amount;
        (bool ok,) = to.call{value: amount}("");
        if (!ok) revert TransferFailed();
        emit Withdrawn(user, to, amount);
    }

    function _isEmpty() internal view override returns (bool) {
        return totalDeposits == 0;
    }
}
