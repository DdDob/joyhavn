// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @notice Pays a fixed ETH amount per period to a hosting/RPC payee, for as
/// long as funds last. Funded at launch. No admin, no way to pull funds back.
contract HostingEscrow {
    address public immutable payee;
    uint256 public immutable start;
    uint256 public immutable period;
    uint256 public immutable amountPerPeriod;
    uint256 public periodsPaid;

    event Funded(address indexed from, uint256 amount);
    event Released(address indexed payee, uint256 periods, uint256 amount);

    error NothingToRelease();
    error TransferFailed();
    error BadConfig();

    constructor(address payee_, uint256 period_, uint256 amountPerPeriod_) payable {
        if (payee_ == address(0) || period_ == 0 || amountPerPeriod_ == 0) revert BadConfig();
        payee = payee_;
        period = period_;
        amountPerPeriod = amountPerPeriod_;
        start = block.timestamp;
        if (msg.value > 0) emit Funded(msg.sender, msg.value);
    }

    receive() external payable {
        emit Funded(msg.sender, msg.value);
    }

    function releasable() public view returns (uint256 periods, uint256 amount) {
        uint256 elapsed = (block.timestamp - start) / period;
        if (elapsed <= periodsPaid) return (0, 0);
        periods = elapsed - periodsPaid;
        uint256 affordable = address(this).balance / amountPerPeriod;
        if (periods > affordable) periods = affordable;
        amount = periods * amountPerPeriod;
    }

    /// Anyone can trigger payment to the payee.
    function release() external {
        (uint256 periods, uint256 amount) = releasable();
        if (amount == 0) revert NothingToRelease();
        periodsPaid += periods;
        (bool ok,) = payee.call{value: amount}("");
        if (!ok) revert TransferFailed();
        emit Released(payee, periods, amount);
    }
}
