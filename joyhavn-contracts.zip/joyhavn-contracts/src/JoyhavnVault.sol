// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Joyhavn} from "./Joyhavn.sol";

interface IERC20 {
    function balanceOf(address) external view returns (uint256);
    function transfer(address, uint256) external returns (bool);
    function transferFrom(address, address, uint256) external returns (bool);
}

/// @notice Example protocol: a simple single-token vault with Joyhavn built in.
contract JoyhavnVault is Joyhavn {
    IERC20 public immutable token;
    mapping(address => uint256) public balanceOf;
    uint256 public totalDeposits;

    event Deposited(address indexed user, uint256 amount);
    event Withdrawn(address indexed user, address indexed to, uint256 amount);

    error ZeroAmount();
    error InsufficientBalance();
    error TransferFailed();

    constructor(IERC20 token_, address governance_, bytes32 exitFrontend_)
        Joyhavn(governance_, exitFrontend_)
    {
        if (address(token_) == address(0)) revert ZeroAddress();
        token = token_;
    }

    /// Deposits only work while Active.
    function deposit(uint256 amount) external whenActive returns (uint256 received) {
        if (amount == 0) revert ZeroAmount();
        uint256 beforeBal = token.balanceOf(address(this));
        _call(abi.encodeCall(IERC20.transferFrom, (msg.sender, address(this), amount)));
        received = token.balanceOf(address(this)) - beforeBal; // handles fee-on-transfer tokens
        balanceOf[msg.sender] += received;
        totalDeposits += received;
        emit Deposited(msg.sender, received);
    }

    /// Withdrawals work in every phase. No admin can block them.
    function withdraw(uint256 amount, address to) external {
        if (amount == 0) revert ZeroAmount();
        _withdraw(msg.sender, amount, to);
    }

    function withdrawAll(address to) external override returns (uint256 amount) {
        amount = balanceOf[msg.sender];
        if (amount == 0) revert ZeroAmount();
        _withdraw(msg.sender, amount, to);
    }

    function _withdraw(address user, uint256 amount, address to) internal {
        if (to == address(0)) revert ZeroAddress();
        if (amount > balanceOf[user]) revert InsufficientBalance();
        balanceOf[user] -= amount; // effects before interaction
        totalDeposits -= amount;
        _call(abi.encodeCall(IERC20.transfer, (to, amount)));
        emit Withdrawn(user, to, amount);
    }

    function _isEmpty() internal view override returns (bool) {
        return totalDeposits == 0;
    }

    function _call(bytes memory data) private {
        (bool ok, bytes memory ret) = address(token).call(data);
        if (!ok || (ret.length != 0 && !abi.decode(ret, (bool)))) revert TransferFailed();
    }
}
