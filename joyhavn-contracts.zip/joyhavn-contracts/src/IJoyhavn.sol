// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @notice Joyhavn: a minimal standard for a safe protocol wind-down.
interface IJoyhavn {
    enum Phase { Active, WindDown, ExitOnly, Archived }

    event PhaseChanged(Phase indexed from, Phase indexed to, uint256 effectiveAt);
    event ExitFrontendSet(bytes32 hash);

    /// Current phase. Wallets read this to show warnings.
    function phase() external view returns (Phase);

    /// Timestamp when WindDown becomes ExitOnly (0 if no wind-down started).
    function windDownEffectiveAt() external view returns (uint256);

    /// Governance starts a wind-down with a public notice period.
    function beginWindDown(uint256 noticeSeconds) external;

    /// Hash of the exit frontend pinned on IPFS/Arweave.
    function exitFrontend() external view returns (bytes32);

    /// Withdraw the caller's entire balance to `to`. Works in EVERY phase.
    function withdrawAll(address to) external returns (uint256);
}
