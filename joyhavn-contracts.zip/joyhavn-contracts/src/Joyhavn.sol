// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {IJoyhavn} from "./IJoyhavn.sol";

/// @notice Base contract implementing the Joyhavn phase machine.
/// Rules enforced here:
///  - Phases only move forward: Active -> WindDown -> ExitOnly -> Archived.
///  - A wind-down needs a public notice of at least MIN_NOTICE.
///  - The exit frontend hash is frozen once a wind-down begins.
///  - Withdrawals are never gated by phase (inheriting contracts must keep it so).
///  - Archiving is only possible once nothing is left to withdraw.
abstract contract Joyhavn is IJoyhavn {
    uint256 public constant MIN_NOTICE = 7 days;

    address public immutable governance;
    uint256 public override windDownEffectiveAt;

    bool private _windDownStarted;
    bool private _archived;
    bool private _exitOnlyAnnounced;
    bytes32 private _exitFrontend;

    error NotGovernance();
    error NotActive();
    error NoticeTooShort();
    error NotExitOnly();
    error NotEmpty();
    error ZeroAddress();

    constructor(address governance_, bytes32 exitFrontend_) {
        if (governance_ == address(0)) revert ZeroAddress();
        governance = governance_;
        _exitFrontend = exitFrontend_;
        emit ExitFrontendSet(exitFrontend_);
    }

    modifier onlyGovernance() {
        if (msg.sender != governance) revert NotGovernance();
        _;
    }

    /// Use on deposit-like functions. Never on withdrawals.
    modifier whenActive() {
        if (phase() != Phase.Active) revert NotActive();
        _;
    }

    function phase() public view override returns (Phase) {
        if (_archived) return Phase.Archived;
        if (!_windDownStarted) return Phase.Active;
        if (block.timestamp < windDownEffectiveAt) return Phase.WindDown;
        return Phase.ExitOnly;
    }

    function exitFrontend() external view override returns (bytes32) {
        return _exitFrontend;
    }

    /// Update the exit frontend hash. Only while Active.
    function setExitFrontend(bytes32 hash) external onlyGovernance whenActive {
        _exitFrontend = hash;
        emit ExitFrontendSet(hash);
    }

    function beginWindDown(uint256 noticeSeconds) external override onlyGovernance whenActive {
        if (noticeSeconds < MIN_NOTICE) revert NoticeTooShort();
        _windDownStarted = true;
        windDownEffectiveAt = block.timestamp + noticeSeconds;
        emit PhaseChanged(Phase.Active, Phase.WindDown, windDownEffectiveAt);
    }

    /// Anyone can call once the notice period is over, so indexers and
    /// wallets get a PhaseChanged event for ExitOnly.
    function announceExitOnly() external {
        if (phase() != Phase.ExitOnly || _exitOnlyAnnounced) revert NotExitOnly();
        _exitOnlyAnnounced = true;
        emit PhaseChanged(Phase.WindDown, Phase.ExitOnly, windDownEffectiveAt);
    }

    /// Anyone can archive once in ExitOnly and everything has been withdrawn.
    function archive() external {
        if (phase() != Phase.ExitOnly) revert NotExitOnly();
        if (!_isEmpty()) revert NotEmpty();
        _archived = true;
        emit PhaseChanged(Phase.ExitOnly, Phase.Archived, block.timestamp);
    }

    /// True when no user funds remain.
    function _isEmpty() internal view virtual returns (bool);
}
