# JOYHAVN: build guide and explainer

## 1. What Joyhavn does
Smart contracts run forever, but the websites, hosting and servers around them do not. When a team leaves, users can be locked out of their own funds even though the contract is fine.

Joyhavn is a standard plus working code that gives a protocol a planned, safe ending:
1. **A phase machine in the contract**: Active, WindDown, ExitOnly, Archived. Phases only move forward.
2. **Withdrawals that never stop**: deposits close during wind-down, but users can always withdraw, with no admin override.
3. **A public notice period**: at least 7 days before the protocol enters ExitOnly, announced on-chain.
4. **An exit frontend that can't vanish**: a tiny static page pinned to IPFS/Arweave, with its hash recorded on-chain and frozen once wind-down starts.
5. **A hosting escrow**: ETH set aside at launch that automatically pays the hosting/RPC provider each period.
6. **Wallet-readable status**: any wallet can call `phase()` and warn users to withdraw.

### Phases
| Phase | Deposits | Withdrawals | Admin can change exit hash |
|---|---|---|---|
| Active | yes | yes | yes |
| WindDown (notice period) | no | yes | no |
| ExitOnly | no | yes | no |
| Archived (only when empty) | no | nothing left | no |

## 2. What is in the repo
- `src/IJoyhavn.sol`: the standard interface.
- `src/Joyhavn.sol`: abstract base with the phase rules. Inherit this.
- `src/JoyhavnVault.sol`: example ERC-20 vault.
- `src/JoyhavnEthVault.sol`: example ETH vault.
- `src/HostingEscrow.sol`: prepaid hosting/RPC escrow.
- `script/Deploy.s.sol`: deployment script.
- `exit-frontend/index.html`: the exit page to pin.
- `test/`: Foundry tests.

## 3. Build it, step by step
**Step 1: tools.** Install Foundry (`curl -L https://foundry.paradigm.xyz | bash`, then `foundryup`) and Node.js.

**Step 2: project.** In the repo folder run `forge init --no-commit --force .` then `forge install foundry-rs/forge-std --no-commit`. Keep the existing files.

**Step 3: test.** Run `forge test -vv`. Fix anything that fails before moving on. Run `forge coverage` to see what is untested.

**Step 4: exit page.** Open `exit-frontend/index.html`. Download the ethers library file it links to and load it from the same folder, so the page has no outside dependency. Open it with `#YOUR_CONTRACT_ADDRESS` on the end of the URL to point it at your vault.

**Step 5: pin it.** Upload the `exit-frontend` folder to IPFS (a pinning service such as Pinata or web3.storage) and also to Arweave for permanence. Record the CID in your docs.

**Step 6: hash.** Compute a 32-byte fingerprint of the bundle, for example `tar cf - exit-frontend | shasum -a 256`. That value is `EXIT_FRONTEND_HASH`. Anyone can later re-hash the pinned files to verify they match.

**Step 7: testnet deploy.** Create a `.env` with: `GOVERNANCE` (a multisig address), `EXIT_FRONTEND_HASH` (0x + the hex), `TOKEN`, `HOSTING_PAYEE`, `ESCROW_WEI`, `ESCROW_PER_PERIOD_WEI`, and optionally `ESCROW_PERIOD_SECONDS`. Then run:
`forge script script/Deploy.s.sol --rpc-url $RPC_URL --account deployer --broadcast --verify`
Do this on a testnet first (for example Sepolia).

**Step 8: rehearse a full wind-down on testnet.** Deposit, call `beginWindDown(604800)`, wait, withdraw using only the pinned exit page, then `archive()`. If this works with the original website offline, it works.

**Step 9: use it in your own protocol.** Make your contract `is Joyhavn`, put `whenActive` on every deposit-like function, never gate withdrawals, implement `withdrawAll` and `_isEmpty()`. Keep the vault contracts as reference.

**Step 10: website.** Publish the Joyhavn site (the page already built) on Vercel. Replace the placeholder email, pricing and links.

**Step 11: mainnet.** Only after a professional audit, bug bounty or review, and legal advice.

## 4. How it earns
- Paid integration and exit-page setup for protocol teams.
- Subscription for monitoring, hosting guarantees and wind-down drills.
- Audit-style readiness badges for launchpads and auditors.
- Grants, since it is a public-good style standard.
A token is not required; it adds legal and regulatory risk, so get advice first.

## 5. Security checklist
- Use a multisig and timelock as governance, never one personal wallet.
- Confirm no function can block `withdraw` or `withdrawAll` in any phase.
- Audit reentrancy, token edge cases (fee-on-transfer, rebasing) and phase transitions.
- Fund the escrow with real amounts; check the payee address twice (it cannot be changed).
- Test the exit page on mobile wallets.

## 6. Known limits of this draft
- Not audited, and not compiled in the environment it was written in.
- Tokens sent directly to a vault (not deposited) stay stuck.
- Governance is one address; phases cannot be cancelled once started, by design.
- The escrow pays a fixed amount; it does not adapt to price changes.
- Joyhavn does not recover funds from contracts that were not built with it.
