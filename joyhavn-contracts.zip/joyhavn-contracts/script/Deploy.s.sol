// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Script, console2} from "forge-std/Script.sol";
import {JoyhavnVault, IERC20} from "../src/JoyhavnVault.sol";
import {HostingEscrow} from "../src/HostingEscrow.sol";

/// Usage (testnet first!):
///   forge script script/Deploy.s.sol --rpc-url $RPC_URL --account deployer --broadcast --verify
contract Deploy is Script {
    function run() external {
        address governance = vm.envAddress("GOVERNANCE");          // use a multisig
        bytes32 exitHash = vm.envBytes32("EXIT_FRONTEND_HASH");    // sha256 of the pinned bundle
        address token = vm.envAddress("TOKEN");                    // ERC-20 the vault holds
        address payee = vm.envAddress("HOSTING_PAYEE");            // who gets hosting/RPC payments
        uint256 escrowWei = vm.envUint("ESCROW_WEI");              // total ETH put aside
        uint256 perPeriod = vm.envUint("ESCROW_PER_PERIOD_WEI");   // paid each period
        uint256 period = vm.envOr("ESCROW_PERIOD_SECONDS", uint256(365 days));

        vm.startBroadcast();
        JoyhavnVault vault = new JoyhavnVault(IERC20(token), governance, exitHash);
        HostingEscrow escrow = new HostingEscrow{value: escrowWei}(payee, period, perPeriod);
        vm.stopBroadcast();

        console2.log("JoyhavnVault:", address(vault));
        console2.log("HostingEscrow:", address(escrow));
    }
}
