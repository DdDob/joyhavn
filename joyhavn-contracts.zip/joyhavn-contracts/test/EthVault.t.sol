// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {IJoyhavn} from "../src/IJoyhavn.sol";
import {JoyhavnEthVault} from "../src/JoyhavnEthVault.sol";

contract EthVaultTest is Test {
    JoyhavnEthVault vault;
    address gov = address(0x60F);
    address alice = address(0xA11CE);

    function setUp() public {
        vault = new JoyhavnEthVault(gov, keccak256("frontend"));
        vm.deal(alice, 10 ether);
        vm.prank(alice); vault.deposit{value: 5 ether}();
    }

    function test_fullLifecycle() public {
        vm.prank(gov); vault.beginWindDown(7 days);
        vm.prank(alice);
        vm.expectRevert();
        vault.deposit{value: 1 ether}();

        vm.warp(block.timestamp + 8 days);
        assertEq(uint8(vault.phase()), uint8(IJoyhavn.Phase.ExitOnly));

        vm.prank(alice); vault.withdrawAll(alice);
        assertEq(alice.balance, 10 ether);

        vault.archive();
        assertEq(uint8(vault.phase()), uint8(IJoyhavn.Phase.Archived));
    }

    function test_plainEthTransferRejected() public {
        vm.prank(alice);
        (bool ok,) = address(vault).call{value: 1 ether}("");
        assertFalse(ok);
    }
}
