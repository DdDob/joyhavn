// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Test} from "forge-std/Test.sol";
import {IJoyhavn} from "../src/IJoyhavn.sol";
import {Joyhavn} from "../src/Joyhavn.sol";
import {JoyhavnVault, IERC20} from "../src/JoyhavnVault.sol";
import {HostingEscrow} from "../src/HostingEscrow.sol";

contract MockToken {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    function mint(address to, uint256 a) external { balanceOf[to] += a; }
    function approve(address s, uint256 a) external returns (bool) { allowance[msg.sender][s] = a; return true; }
    function transfer(address to, uint256 a) external returns (bool) {
        balanceOf[msg.sender] -= a; balanceOf[to] += a; return true;
    }
    function transferFrom(address f, address to, uint256 a) external returns (bool) {
        allowance[f][msg.sender] -= a; balanceOf[f] -= a; balanceOf[to] += a; return true;
    }
}

contract JoyhavnTest is Test {
    MockToken token;
    JoyhavnVault vault;
    address gov = address(0x60F);
    address alice = address(0xA11CE);
    address bob = address(0xB0B);
    bytes32 constant FE = keccak256("ipfs-exit-frontend-v1");

    function setUp() public {
        token = new MockToken();
        vault = new JoyhavnVault(IERC20(address(token)), gov, FE);
        token.mint(alice, 1000e18);
        token.mint(bob, 500e18);
        vm.prank(alice); token.approve(address(vault), type(uint256).max);
        vm.prank(bob); token.approve(address(vault), type(uint256).max);
        vm.prank(alice); vault.deposit(100e18);
    }

    function test_startsActive() public view {
        assertEq(uint8(vault.phase()), uint8(IJoyhavn.Phase.Active));
        assertEq(vault.exitFrontend(), FE);
    }

    function test_onlyGovernanceCanBeginWindDown() public {
        vm.prank(alice);
        vm.expectRevert(Joyhavn.NotGovernance.selector);
        vault.beginWindDown(7 days);
    }

    function test_noticeMustBeLongEnough() public {
        vm.prank(gov);
        vm.expectRevert(Joyhavn.NoticeTooShort.selector);
        vault.beginWindDown(6 days);
    }

    function test_windDownBlocksDepositsButNotWithdrawals() public {
        vm.prank(gov); vault.beginWindDown(7 days);
        assertEq(uint8(vault.phase()), uint8(IJoyhavn.Phase.WindDown));

        vm.prank(bob);
        vm.expectRevert(Joyhavn.NotActive.selector);
        vault.deposit(10e18);

        vm.prank(alice); vault.withdraw(40e18, alice);
        assertEq(vault.balanceOf(alice), 60e18);
    }

    function test_becomesExitOnlyAfterNotice() public {
        vm.prank(gov); vault.beginWindDown(7 days);
        vm.warp(block.timestamp + 7 days);
        assertEq(uint8(vault.phase()), uint8(IJoyhavn.Phase.ExitOnly));
        vault.announceExitOnly();
        vm.expectRevert(Joyhavn.NotExitOnly.selector);
        vault.announceExitOnly(); // only once
    }

    function test_withdrawAllWorksInExitOnlyEvenIfGovernanceIsGone() public {
        vm.prank(gov); vault.beginWindDown(7 days);
        vm.warp(block.timestamp + 365 days);
        vm.prank(alice);
        uint256 out = vault.withdrawAll(bob); // to a different address
        assertEq(out, 100e18);
        assertEq(token.balanceOf(bob), 600e18);
    }

    function test_cannotArchiveWhileFundsRemain() public {
        vm.prank(gov); vault.beginWindDown(7 days);
        vm.warp(block.timestamp + 7 days);
        vm.expectRevert(Joyhavn.NotEmpty.selector);
        vault.archive();
    }

    function test_archiveWhenEmpty() public {
        vm.prank(gov); vault.beginWindDown(7 days);
        vm.warp(block.timestamp + 7 days);
        vm.prank(alice); vault.withdrawAll(alice);
        vault.archive();
        assertEq(uint8(vault.phase()), uint8(IJoyhavn.Phase.Archived));
    }

    function test_cannotArchiveBeforeExitOnly() public {
        vm.expectRevert(Joyhavn.NotExitOnly.selector);
        vault.archive();
    }

    function test_exitFrontendFrozenAfterWindDownStarts() public {
        vm.prank(gov); vault.setExitFrontend(keccak256("v2"));
        vm.prank(gov); vault.beginWindDown(7 days);
        vm.prank(gov);
        vm.expectRevert(Joyhavn.NotActive.selector);
        vault.setExitFrontend(keccak256("evil"));
    }

    function test_cannotWithdrawMoreThanBalance() public {
        vm.prank(bob);
        vm.expectRevert(JoyhavnVault.InsufficientBalance.selector);
        vault.withdraw(1, bob);
    }

    function test_cannotWindDownTwice() public {
        vm.startPrank(gov);
        vault.beginWindDown(7 days);
        vm.expectRevert(Joyhavn.NotActive.selector);
        vault.beginWindDown(30 days);
        vm.stopPrank();
    }

    function testFuzz_withdrawNeverExceedsDeposit(uint96 a, uint96 w) public {
        a = uint96(bound(a, 1, 400e18));
        vm.prank(bob); vault.deposit(a);
        w = uint96(bound(w, 0, type(uint96).max));
        vm.prank(bob);
        if (w == 0) { vm.expectRevert(JoyhavnVault.ZeroAmount.selector); }
        else if (w > a) { vm.expectRevert(JoyhavnVault.InsufficientBalance.selector); }
        vault.withdraw(w, bob);
    }

    // ---- HostingEscrow ----
    function test_escrowReleasesPerPeriod() public {
        address payee = address(0xBEEF);
        HostingEscrow esc = new HostingEscrow{value: 3 ether}(payee, 365 days, 1 ether);
        vm.expectRevert(HostingEscrow.NothingToRelease.selector);
        esc.release();

        vm.warp(block.timestamp + 365 days);
        esc.release();
        assertEq(payee.balance, 1 ether);

        vm.warp(block.timestamp + 5 * 365 days); // more elapsed than funded
        esc.release();
        assertEq(payee.balance, 3 ether); // capped at what was funded
        assertEq(address(esc).balance, 0);
    }
}
