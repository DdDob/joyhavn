// Read-only Solana JSON-RPC helpers (devnet) for the Wallet page.
const DEVNET_USDC = '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU';

export function createRpc({ url = process.env.SOLANA_RPC_URL || 'https://api.devnet.solana.com', fetchImpl = fetch } = {}) {
  async function call(method, params) {
    const res = await fetchImpl(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
      signal: AbortSignal.timeout(6000),
    });
    const json = await res.json();
    if (json.error) throw new Error(json.error.message || 'RPC error');
    return json.result;
  }

  return {
    async balances(address) {
      const [sol, tokens] = await Promise.all([
        call('getBalance', [address, { commitment: 'confirmed' }]),
        call('getTokenAccountsByOwner', [address, { mint: DEVNET_USDC }, { encoding: 'jsonParsed' }]),
      ]);
      const usdc = (tokens?.value || []).reduce(
        (n, a) => n + Number(a?.account?.data?.parsed?.info?.tokenAmount?.uiAmount || 0),
        0,
      );
      return { sol: (sol?.value || 0) / 1e9, usdc, hasUsdcAccount: (tokens?.value || []).length > 0 };
    },
  };
}
